// src/components/dashboard/audience/contacts/contacts-header.tsx

import { PortalHeroHeader } from "../../portal-hero-header";

export function ContactsHeader() {
  return (
    <PortalHeroHeader
      breadcrumb="Audience"
      title="Contacts"
      description="Everyone you can reach by email or SMS, with consent and segment membership in one place."
    />
  );
}
