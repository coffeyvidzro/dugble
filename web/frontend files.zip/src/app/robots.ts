// src/app/robots.ts

import type { MetadataRoute } from "next";
import { baseUrl } from "@/lib/site";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      allow: "/",
      disallow: ["/dashboard", "/dashboard/"],
    },
    sitemap: `${baseUrl}/sitemap.xml`,
  };
}
